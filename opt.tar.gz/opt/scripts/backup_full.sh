#!/bin/bash
# backup_full.sh - Hace un backup comprimido de un directorio

# Opcion de ayuda
if [ "$1" = "-help" ]; then
    echo "Uso: backup_full.sh <origen> <destino>"
    echo "Ejemplo: backup_full.sh /var/log /backup_dir"
    echo "Genera el archivo <nombre>_bkp_AAAAMMDD.tar.gz en el destino"
    exit 0
fi

# Verifica que se pasen origen y destino
if [ $# -ne 2 ]; then
    echo "Error: faltan argumentos. Use -help para ver la ayuda"
    exit 1
fi

ORIGEN=$1
DESTINO=$2

# Valida que el origen y el destino esten disponibles
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el origen $ORIGEN no esta disponible"
    exit 1
fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: el destino $DESTINO no esta montado"
    exit 1
fi

# Nombre con fecha en formato ANSI (AAAAMMDD)
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

# Crea el backup en el destino
tar -czf "$ARCHIVO" "$ORIGEN"
echo "Backup creado: $ARCHIVO"

